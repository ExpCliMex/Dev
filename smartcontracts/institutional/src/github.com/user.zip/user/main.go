/*
 * SPDX-License-Identifier: Apache-2.0
 */

package main

import (
	"github.com/hyperledger/fabric-contract-api-go/contractapi"
	"github.com/hyperledger/fabric-contract-api-go/metadata"
)

func main() {
	institutionalUserContract := new(InstitutionalUserContract)
	institutionalUserContract.Info.Version = "0.0.1"
	institutionalUserContract.Info.Description = "My Smart Contract"
	institutionalUserContract.Info.License = new(metadata.LicenseMetadata)
	institutionalUserContract.Info.License.Name = "Apache-2.0"
	institutionalUserContract.Info.Contact = new(metadata.ContactMetadata)
	institutionalUserContract.Info.Contact.Name = "John Doe"

	chaincode, err := contractapi.NewChaincode(institutionalUserContract)
	chaincode.Info.Title = "user chaincode"
	chaincode.Info.Version = "0.0.1"

	if err != nil {
		panic("Could not create chaincode from InstitutionalUserContract." + err.Error())
	}

	err = chaincode.Start()

	if err != nil {
		panic("Failed to start chaincode. " + err.Error())
	}
}
