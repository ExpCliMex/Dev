/*
 * SPDX-License-Identifier: Apache-2.0
 */

package main

import (
	"encoding/json"
	"errors"
	"fmt"
	"testing"

	"github.com/hyperledger/fabric-chaincode-go/shim"
	"github.com/hyperledger/fabric-contract-api-go/contractapi"
	"github.com/stretchr/testify/assert"
	"github.com/stretchr/testify/mock"
)

const getStateError = "world state get error"

type MockStub struct {
	shim.ChaincodeStubInterface
	mock.Mock
}

func (ms *MockStub) GetState(key string) ([]byte, error) {
	args := ms.Called(key)

	return args.Get(0).([]byte), args.Error(1)
}

func (ms *MockStub) PutState(key string, value []byte) error {
	args := ms.Called(key, value)

	return args.Error(0)
}

func (ms *MockStub) DelState(key string) error {
	args := ms.Called(key)

	return args.Error(0)
}

type MockContext struct {
	contractapi.TransactionContextInterface
	mock.Mock
}

func (mc *MockContext) GetStub() shim.ChaincodeStubInterface {
	args := mc.Called()

	return args.Get(0).(*MockStub)
}

func configureStub() (*MockContext, *MockStub) {
	var nilBytes []byte

	testUser := new(User)
	testUser.Username = "username"
	testUser.Name = "name"
	testUser.LastName = "lastname"
	testUser.Email = "email@example.com"
	testUser.Password = "password"
	userBytes, _ := json.Marshal(testUser)

	ms := new(MockStub)
	ms.On("GetState", "statebad").Return(nilBytes, errors.New(getStateError))
	ms.On("GetState", "missingkey").Return(nilBytes, nil)
	ms.On("GetState", "existingkey").Return([]byte("some value"), nil)
	ms.On("GetState", "userkey").Return(userBytes, nil)
	ms.On("PutState", mock.AnythingOfType("string"), mock.AnythingOfType("[]uint8")).Return(nil)
	ms.On("DelState", mock.AnythingOfType("string")).Return(nil)

	mc := new(MockContext)
	mc.On("GetStub").Return(ms)

	return mc, ms
}

func TestUserExists(t *testing.T) {
	var exists bool
	var err error

	ctx, _ := configureStub()
	c := new(UserContract)

	exists, err = c.UserExists(ctx, "statebad")
	assert.EqualError(t, err, getStateError)
	assert.False(t, exists, "should return false on error")

	exists, err = c.UserExists(ctx, "missingkey")
	assert.Nil(t, err, "should not return error when can read from world state but no value for key")
	assert.False(t, exists, "should return false when no value for key in world state")

	exists, err = c.UserExists(ctx, "existingkey")
	assert.Nil(t, err, "should not return error when can read from world state and value exists for key")
	assert.True(t, exists, "should return true when value for key in world state")
}

func TestCreateUser(t *testing.T) {
	var err error

	ctx, stub := configureStub()
	c := new(UserContract)

	var testinput [5]string
	testinput[0] = "username"
	testinput[1] = "name"
	testinput[2] = "lastname"
	testinput[3] = "email@example.com"
	testinput[4] = "password"

	err = c.CreateUser(ctx, "statebad", testinput[:])
	assert.EqualError(t, err, fmt.Sprintf("Could not read from world state. %s", getStateError), "should error when exists errors")

	err = c.CreateUser(ctx, "existingkey", testinput[:])
	assert.EqualError(t, err, "The asset existingkey already exists", "should error when exists returns true")

	err = c.CreateUser(ctx, "missingkey", testinput[:])
	stub.AssertCalled(t, "PutState", "missingkey", []byte("{\"value\":\"some value\"}"))
}

func TestReadUser(t *testing.T) {
	var user *User
	var err error

	ctx, _ := configureStub()
	c := new(UserContract)

	user, err = c.ReadUser(ctx, "statebad")
	assert.EqualError(t, err, fmt.Sprintf("Could not read from world state. %s", getStateError), "should error when exists errors when reading")
	assert.Nil(t, user, "should not return User when exists errors when reading")

	user, err = c.ReadUser(ctx, "missingkey")
	assert.EqualError(t, err, "The asset missingkey does not exist", "should error when exists returns true when reading")
	assert.Nil(t, user, "should not return User when key does not exist in world state when reading")

	user, err = c.ReadUser(ctx, "existingkey")
	assert.EqualError(t, err, "Could not unmarshal world state data to type User", "should error when data in key is not User")
	assert.Nil(t, user, "should not return User when data in key is not of type User")

	user, err = c.ReadUser(ctx, "userkey")
	expectedUser := new(User)
	expectedUser.Username = "username"
	expectedUser.Name = "name"
	expectedUser.LastName = "lastname"
	expectedUser.Email = "email@example.com"
	expectedUser.Password = "password"
	assert.Nil(t, err, "should not return error when User exists in world state when reading")
	assert.Equal(t, expectedUser, user, "should return deserialized User from world state")
}

func TestUpdateUser(t *testing.T) {
	var err error

	ctx, stub := configureStub()
	c := new(UserContract)

	var testinput [5]string
	testinput[0] = "username"
	testinput[1] = "nameupdated"
	testinput[2] = "lastnameupdated"
	testinput[3] = "emailupdated@example.com"
	testinput[4] = "passwordupdated"

	err = c.UpdateUser(ctx, "statebad", testinput[:])
	assert.EqualError(t, err, fmt.Sprintf("Could not read from world state. %s", getStateError), "should error when exists errors when updating")

	err = c.UpdateUser(ctx, "missingkey", testinput[:])
	assert.EqualError(t, err, "The asset missingkey does not exist", "should error when exists returns true when updating")

	err = c.UpdateUser(ctx, "userkey", testinput[:])
	expectedUser := new(User)
	expectedUser.Username = "username"
	expectedUser.Name = "name"
	expectedUser.LastName = "lastname"
	expectedUser.Email = "email@example.com"
	expectedUser.Password = "password"
	expectedUserBytes, _ := json.Marshal(expectedUser)
	assert.Nil(t, err, "should not return error when User exists in world state when updating")
	stub.AssertCalled(t, "PutState", "userkey", expectedUserBytes)
}

func TestDeleteUser(t *testing.T) {
	var err error

	ctx, stub := configureStub()
	c := new(UserContract)

	err = c.DeleteUser(ctx, "statebad")
	assert.EqualError(t, err, fmt.Sprintf("Could not read from world state. %s", getStateError), "should error when exists errors")

	err = c.DeleteUser(ctx, "missingkey")
	assert.EqualError(t, err, "The asset missingkey does not exist", "should error when exists returns true when deleting")

	err = c.DeleteUser(ctx, "userkey")
	assert.Nil(t, err, "should not return error when User exists in world state when deleting")
	stub.AssertCalled(t, "DelState", "userkey")
}

func TestInitUserContract(t *testing.T) {
	var err error

	ctx, stub := configureStub()
	c := new(UserContract)

	err = c.InitUserContract(ctx)
	assert.Nil(t, err, "should not return error when Initialize smartcontract")
	stub.AssertCalled(t, "InitContract", "Ok")
}