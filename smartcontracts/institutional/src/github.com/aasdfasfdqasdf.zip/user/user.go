/*
 * SPDX-License-Identifier: Apache-2.0
 */

package main

// User stores a value
type User struct{
	Name string `json:"name"`
	LastName string `json:"lastname"`
	Email string `json:"email"`
	Username string `json:"username"`
	Password string `json:"password"`
}