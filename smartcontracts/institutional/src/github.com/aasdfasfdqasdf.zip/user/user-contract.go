/*
 * SPDX-License-Identifier: Apache-2.0
 */

package main

import (
	"encoding/json"
	"fmt"

	"github.com/hyperledger/fabric-chaincode-go/shim"
	"github.com/hyperledger/fabric-contract-api-go/contractapi"
	sc "github.com/hyperledger/fabric-protos-go/peer"
)

// UserContract contract for managing CRUD for User
type UserContract struct {
	contractapi.Contract
}

func (c *UserContract) Init(APIstub shim.ChaincodeStubInterface) sc.Response {
	return shim.Success(nil)
}

// UserExists returns true when asset with given ID exists in world state
func (c *UserContract) UserExists(ctx contractapi.TransactionContextInterface, userID string) (bool, error) {
	data, err := ctx.GetStub().GetState(userID)

	if err != nil {
		return false, err
	}

	return data != nil, nil
}

// CreateUser creates a new instance of User
func (c *UserContract) CreateUser(ctx contractapi.TransactionContextInterface, userID string, par []string) error {
	exists, err := c.UserExists(ctx, userID)
	if err != nil {
		return fmt.Errorf("Could not read from world state. %s", err)
	} else if exists {
		return fmt.Errorf("The asset %s already exists", userID)
	}

	user := new(User)
	user.Username = par[0]
	user.Name = par[1]
	user.LastName = par[2]
	user.Email = par[3]
	user.Password = par[4]

	bytes, _ := json.Marshal(user)

	return ctx.GetStub().PutState(userID, bytes)
}

// ReadUser retrieves an instance of User from the world state
func (c *UserContract) ReadUser(ctx contractapi.TransactionContextInterface, userID string) (*User, error) {
	exists, err := c.UserExists(ctx, userID)
	if err != nil {
		return nil, fmt.Errorf("Could not read from world state. %s", err)
	} else if !exists {
		return nil, fmt.Errorf("The asset %s does not exist", userID)
	}

	bytes, _ := ctx.GetStub().GetState(userID)

	user := new(User)

	err = json.Unmarshal(bytes, user)

	if err != nil {
		return nil, fmt.Errorf("Could not unmarshal world state data to type User")
	}

	return user, nil
}

// UpdateUser retrieves an instance of User from the world state and updates its value
func (c *UserContract) UpdateUser(ctx contractapi.TransactionContextInterface, userID string, par []string) error {
	exists, err := c.UserExists(ctx, userID)
	if err != nil {
		return fmt.Errorf("Could not read from world state. %s", err)
	} else if !exists {
		return fmt.Errorf("The asset %s does not exist", userID)
	}

	user := new(User)
	user.Username = userID
	user.Name = par[1]
	user.LastName = par[2]
	user.Email = par[3]
	user.Password = par[4]

	bytes, _ := json.Marshal(user)

	return ctx.GetStub().PutState(userID, bytes)
}

// DeleteUser deletes an instance of User from the world state
func (c *UserContract) DeleteUser(ctx contractapi.TransactionContextInterface, userID string) error {
	exists, err := c.UserExists(ctx, userID)
	if err != nil {
		return fmt.Errorf("Could not read from world state. %s", err)
	} else if !exists {
		return fmt.Errorf("The asset %s does not exist", userID)
	}

	return ctx.GetStub().DelState(userID)
}

func (c *UserContract) InitUserContract(ctx contractapi.TransactionContextInterface) error {
	
	users := []User{
		User{Username: "root", Name: "root", LastName: "", Email: "", Password: "admin123"},
		User{Username: "admin", Name: "admin", LastName: "", Email: "", Password: "admin123"},
	}

	APIstub := ctx.GetStub()
	i := 0
	for i < len(users) {
		carAsBytes, _ := json.Marshal(users[i])
		APIstub.PutState(users[i].Username, carAsBytes)
		i = i + 1
	}

	return nil
}