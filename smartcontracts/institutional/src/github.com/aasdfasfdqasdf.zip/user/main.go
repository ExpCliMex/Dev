/*
 * SPDX-License-Identifier: Apache-2.0
 */

package main

import (
	"github.com/hyperledger/fabric-contract-api-go/contractapi"
	"github.com/hyperledger/fabric-contract-api-go/metadata"
)

func main() {
	userContract := new(UserContract)
	userContract.Info.Version = "0.0.1"
	userContract.Info.Description = "My Smart Contract"
	userContract.Info.License = new(metadata.LicenseMetadata)
	userContract.Info.License.Name = "Apache-2.0"
	userContract.Info.Contact = new(metadata.ContactMetadata)
	userContract.Info.Contact.Name = "John Doe"

	chaincode, err := contractapi.NewChaincode(userContract)
	chaincode.Info.Title = "user chaincode"
	chaincode.Info.Version = "0.0.1"

	if err != nil {
		panic("Could not create chaincode from UserContract." + err.Error())
	}

	err = chaincode.Start()

	if err != nil {
		panic("Failed to start chaincode. " + err.Error())
	}
}
